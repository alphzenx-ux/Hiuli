const chatLog = document.getElementById('chat-log');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
const modelSelect = document.getElementById('model-select');

// Fetch models and populate the dropdown
window.addEventListener('load', () => {
  fetch('http://localhost:3000/models')
    .then(response => response.json())
    .then(models => {
      models.forEach(model => {
        const option = document.createElement('option');
        option.value = model;
        option.innerText = model;
        modelSelect.appendChild(option);
      });
    })
    .catch(error => {
      console.error('Error fetching models:', error);
    });
});

sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    sendMessage();
  }
});

function sendMessage() {
  const userMessage = userInput.value;
  const selectedModel = modelSelect.value;
  if (userMessage.trim() !== '') {
    appendMessage('user', userMessage);
    userInput.value = '';
    fetch('http://localhost:3000/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: userMessage, model: selectedModel })
    })
    .then(response => response.json())
    .then(data => {
      appendMessage('bot', data.message);
    })
    .catch(error => {
      console.error('Error:', error);
      appendMessage('bot', 'Sorry, something went wrong.');
    });
  }
}

function appendMessage(sender, message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', `${sender}-message`);
  messageElement.innerText = message;
  chatLog.appendChild(messageElement);
  chatLog.scrollTop = chatLog.scrollHeight;
}
