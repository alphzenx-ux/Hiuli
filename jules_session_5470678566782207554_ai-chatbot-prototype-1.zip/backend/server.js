const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const port = 3000;

const aiModels = Array.from({ length: 25 }, (_, i) => `Model ${i + 1}`);

app.get('/models', (req, res) => {
  res.json(aiModels);
});

app.post('/chat', (req, res) => {
  const { message, model } = req.body;
  if (!model || !aiModels.includes(model)) {
    return res.status(400).json({ error: 'Invalid model selected.' });
  }
  const botResponse = `${model} says: You said: "${message}"`;
  res.json({ message: botResponse });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
